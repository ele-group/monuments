<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXEvent; 

class Menu extends AbstractForm
{
    /**
     * @event button_exit.mouseDown-Left 
     */
    function doButton_exitMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button_game.mouseDown-Left 
     */
    function doButton_gameMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button_map.mouseDown-Left 
     */
    function doButton_mapMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button_map.mouseEnter 
     */
    function doButton_mapMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button_map.mouseExit 
     */
    function doButton_mapMouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event image_lock.mouseDown-Left 
     */
    function doImage_lockMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }
}
