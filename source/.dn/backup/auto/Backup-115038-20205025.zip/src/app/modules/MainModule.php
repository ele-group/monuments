<?php
namespace app\modules;

use php\gui\framework\AbstractModule;
use php\gui\framework\ScriptEvent; 


class MainModule extends AbstractModule
{

    /**
     * @event player.play 
     */
    function doPlayerPlay(ScriptEvent $event = null)
    {    
        
    }

}
